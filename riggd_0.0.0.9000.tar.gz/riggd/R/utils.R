#' Get Counties for a State out of Clean Reg Files
#'
#' @param reg Registration File location
#' @return A character vector of counties
#' @examples
#' counties(reg_colorado_16)
counties <- function(file_source){
  out <- read_csv(file_source, col_types = cols_only(COUNTY = col_guess()))
  unique(out)
}


#' Get total registrants per year per county
#'
#' 
#' @return A dataframe of registrants per year and county, 2012-2016
#' @examples
#' yearXcounty_reg()

yearXcounty_reg <- function(filesource){
  
  CO_county_names <- counties("2016reg2.csv") %>%
    rename(county = COUNTY)
  
  # read in each year's data and add year col
  d1 <- read_csv("2016reg2.csv", 
                 col_types = cols_only(VOTER_ID = col_guess(), COUNTY = col_guess()))
  d1 <- mutate(d1, year = 2016)
  
  d2 <- read_csv("2015reg2.csv", 
                 col_types = cols_only(VOTER_ID = col_guess(), COUNTY = col_guess()))
  d2 <- mutate(d2, year = 2015)
  
  d3 <- read_csv("2014reg2.csv", 
                 col_types = cols_only(VOTER_ID = col_guess(), COUNTY = col_guess()))
  d3 <- mutate(d3, year = 2014)
  
  d4 <- read_csv("2013reg2.csv", 
                 col_types = cols_only(VOTER_ID = col_guess(), COUNTY = col_guess()))
  d4 <- mutate(d4, year = 2013)
  
  d5 <- read_csv("2012reg2.csv", 
                 col_types = cols_only(VOTER_ID = col_guess(), COUNTY = col_guess()))
  d5 <- mutate(d5, year = 2012)
  
  # join data sets
  reg_data <- rbind(d1, d2, d3, d4, d5)
  rm(d1, d2, d3, d4, d5)
  reg_data <- reg_data %>%
    rename(id = VOTER_ID, county = COUNTY)
  
  # form useful data format
  yearXcounty <- reg_data %>%
    group_by(year, county) %>%
    summarize(cnt = n())
  
  # TODO better grab vector of county names and join with inner or outer. Be sure this is right!
  yearXcounty <- inner_join(yearXcounty, CO_county_names, by = "county")
  
  yearXcounty <- yearXcounty %>%
    spread(key = year, value = cnt)
  
  yearXcounty
}